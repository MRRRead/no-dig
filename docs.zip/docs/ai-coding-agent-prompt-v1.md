
# NO-DIG AI Coding Agent Prompt — v1 (June 2025)

## Purpose

You are building a **business-focused Obsidian-to-11ty bridge + plugin host**.

## Architectural Boundaries

🚫 NOT a new SSG  
🚫 NOT replacing 11ty  
🚫 NOT rendering HTML  

✅ Parses Obsidian vault  
✅ Runs plugins pre-11ty  
✅ Adapter prepares 11ty data → invokes 11ty  
✅ 11ty renders final site  

## Scope of Work

### PluginHost

✅ runHook()  
✅ Hooks:
- onBuildStart
- onVaultParsed
- onVaultPagePrepared
- onBuildEnd

### parseVault()

✅ Parse vault → vaultPages array

### adapter-11ty

✅ prepare11tyData(pages) → calls Eleventy

### CLI

✅ `no-dig build` → full pipeline

### Plugin Constraints

🚫 No HTML rendering  
🚫 No template duplication  
🚫 No Eleventy replacement  

## Testing

✅ TDD → write tests first  
✅ Unit tests  
✅ Integration tests  
✅ End-to-end tests  

## Conclusion

Follow `/docs/architecture-and-features-v2.md` and `/docs/plugin-api-v2.md`.  
Avoid scope creep. Keep architecture **Clean Code aligned**.
